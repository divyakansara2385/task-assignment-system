from pathlib import Path
from typing import Optional

import joblib
import numpy as np


class AssignmentPredictor:

    def __init__(self):

        self.model = None

        self.model_path = (
            Path(__file__).resolve().parent
            / "model"
            / "assignment_model.pkl"
        )

        self.load_model()

    # =========================================================
    # LOAD MODEL
    # =========================================================

    def load_model(self):

        if not self.model_path.exists():

            print(
                f"[ML] Model not found: "
                f"{self.model_path}"
            )

            print(
                "[ML] Running in fallback scoring mode."
            )

            return

        try:

            self.model = joblib.load(
                self.model_path
            )

            print(
                "[ML] Assignment model loaded."
            )

        except Exception as exc:

            print(
                f"[ML] Could not load model: {exc}"
            )

            self.model = None

    # =========================================================
    # PREDICT
    # =========================================================

    def predict(
        self,
        skill_match: float,
        experience_match: float,
        availability: float,
        reliability: float,
    ) -> Optional[float]:

        if self.model is None:
            return None

        features = np.array([
            [
                skill_match,
                experience_match,
                availability,
                reliability,
            ]
        ])

        try:

            # Classification model
            if hasattr(
                self.model,
                "predict_proba",
            ):

                probability = (
                    self.model
                    .predict_proba(features)[0]
                )

                # Positive class probability
                if len(probability) >= 2:

                    return round(
                        float(
                            probability[1]
                        ) * 100,
                        2,
                    )

                return round(
                    float(probability[0])
                    * 100,
                    2,
                )

            # Regression model
            prediction = self.model.predict(
                features
            )[0]

            prediction = float(prediction)

            # Normalize if model returns 0-1
            if 0 <= prediction <= 1:
                prediction *= 100

            return round(
                max(
                    0,
                    min(prediction, 100),
                ),
                2,
            )

        except Exception as exc:

            print(
                f"[ML] Prediction failed: {exc}"
            )

            return None